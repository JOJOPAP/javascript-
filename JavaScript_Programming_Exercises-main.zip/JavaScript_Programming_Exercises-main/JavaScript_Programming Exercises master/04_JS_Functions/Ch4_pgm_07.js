// Using the findTotal function to display a calculation

var number1 = 1000;
var number2 = 66;
var result;
var findTotal;

findTotal = function () {
	result = number1 + number2;
};

findTotal();

console.log(number1 + " + " + number2 + " = " + result);



/* Further Adventures
 *
 * 1) Change number1 and number2 and run the program
 *
 * 2) Add a third variable, number3, and assign it a value
 *
 * 3) Update the findTotal function to add the three numbers
 *
 * 4) Update the console.log line to show the new calculation
 *
 */

//answer//
var number1 = 2000;
var number2 = 33;
var result;
var findTotal;
findTotal = function () {
	result = number1 + number2;
};
findTotal();
console.log(number1 + " + " + number2 + " = " + result);
var number1 = 2000;
var number2 = 33;
var number3 = 25;
var result;
var findTotal;
findTotal = function () {
	result = number1 + number2;
};
findTotal();
console.log(number1 + " + " + number2 + " = " + result);
var number1 = 2000;
var number2 = 33;
var number3 = 25;
var result;
var findTotal;
findTotal = function () {
	result = number1 + number2 + number3;
};
findTotal();
console.log(number1 + " + " + number2 + " + " + number3 + " = " + result);
var number1 = 2000;
var number2 = 33;
var number3 = 25;
var result;
var findTotal;
findTotal = function () {
	result = number1 + number2 + number3;
};
findTotal();
console.log(number1 + " + " + number2 + " + " + number3 + " = " + result);