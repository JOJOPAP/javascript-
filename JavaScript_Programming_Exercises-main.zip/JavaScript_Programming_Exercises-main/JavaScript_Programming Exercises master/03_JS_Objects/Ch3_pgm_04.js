// Creating an empty object

var book;

book = {};


/* Further Adventures
 *
 * 1) Log book to the console.
 *
 * 2) Place your cursor between the curly braces
 *    in the code above and press enter.
 *    JS Bin should add an empty line between
 *    the braces. You can add more empty lines.
 *
 * 3) Run the program again, logging book
 *    to the console.
 *    The extra lines should make no difference
 *    to the outcome.
 *
 */

//answer//
var book;
book = {
};
console.log(book);