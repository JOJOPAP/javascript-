// Using console.log to display information

console.log("Hello World!");


/* Further Adventures
 *
 * 1) Change the text between the parentheses.
 *
 * 2) Click Run on the console to run the program again.
 *
 * 3) Add your own console.log statement
 *    to the program, so there are two.
 *    Don't forget the semicolon.
 *
 * 4) Click Run.
 *
 */
// Using console.log to display information

//answer//
console.log("Hello Universe!");
console.log("This is my first JavaScript program.");